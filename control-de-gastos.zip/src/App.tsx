import { useState, useEffect, useMemo } from 'react';
import { Transaction, Category, Budget } from './types';
import {
  loadTransactions,
  saveTransactions,
  loadCategories,
  saveCategories,
  loadBudgets,
  saveBudgets,
  INITIAL_TRANSACTIONS,
  DEFAULT_CATEGORIES
} from './data';
import { calculateTotals, formatCurrency } from './utils/financeUtils';
import { TransactionList } from './components/TransactionList';
import { TransactionForm } from './components/TransactionForm';
import { ReportView } from './components/ReportView';
import { CategoryManager } from './components/CategoryManager';
import { BudgetManager } from './components/BudgetManager';
import {
  Plus,
  Tag,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Wallet,
  Settings,
  HelpCircle,
  FileSpreadsheet,
  Grid,
  Percent,
  Sparkles,
  Info,
  Check,
  X,
  AlertTriangle,
  Bell,
  Flame,
  ShieldAlert
} from 'lucide-react';

export default function App() {
  // 1. ESTADO GLOBAL
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [currencySymbol, setCurrencySymbol] = useState<string>('$');
  const [activeTab, setActiveTab] = useState<'historial' | 'informes' | 'presupuestos'>('historial');
  const [showSettings, setShowSettings] = useState<boolean>(false);

  // Estados de control para Modales
  const [showTransactionModal, setShowTransactionModal] = useState<boolean>(false);
  const [showCategoryModal, setShowCategoryModal] = useState<boolean>(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  // Mensaje de éxito o alerta flotante temporal
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  // Cargar datos iniciales al arrancar la aplicación
  useEffect(() => {
    setTransactions(loadTransactions());
    setCategories(loadCategories());
    setBudgets(loadBudgets());
    
    // Recuperar símbolo de moneda si existe
    const storedCurrency = localStorage.getItem('finanzas_pref_moneda');
    if (storedCurrency) {
      setCurrencySymbol(storedCurrency);
    }
  }, []);

  // Disparar toast temporal
  const triggerToast = (message: string, type: 'success' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // 2. CONTROLADORES DE TRANSACCIONES
  const checkBudgetAlertOnAddition = (catId: string, additionalAmount: number, allTx: Transaction[]) => {
    const budget = budgets.find(b => b.categoryId === catId);
    if (!budget || budget.amount <= 0) return;

    const cat = categories.find(c => c.id === catId);
    if (!cat) return;

    // Sum transactions in current month (Mayo 2026)
    const currentYear = 2026;
    const currentMonthNum = 5;

    const currentSpent = allTx
      .filter(t => {
        if (t.category !== catId) return false;
        const [y, m] = t.date.split('-').map(Number);
        return y === currentYear && m === currentMonthNum;
      })
      .reduce((sum, t) => sum + t.amount, 0);

    const pctNow = currentSpent / budget.amount;
    const previousSpent = currentSpent - additionalAmount;
    const pctBefore = previousSpent / budget.amount;

    if (cat.type === 'gasto') {
      if (pctNow >= 1.0 && pctBefore < 1.0) {
        triggerToast(`🚨 ¡PRESUPUESTO EXCEDIDO! Has superado el límite de ${formatCurrency(budget.amount, currencySymbol)} en la categoría "${cat.name}".`, 'info');
      } else if (pctNow >= 0.8 && pctBefore < 0.8) {
        triggerToast(`⚠️ ¡ALERTA DE PRESUPUESTO! Estás cerca de agotar el límite de "${cat.name}" (consumido el ${(pctNow * 100).toFixed(0)}%).`, 'info');
      }
    } else {
      // Income Goal reached
      if (pctNow >= 1.0 && pctBefore < 1.0) {
        triggerToast(`🎉 ¡META ALCANZADA! Enhorabuena, has logrado tu meta de ingresos de ${formatCurrency(budget.amount, currencySymbol)} en "${cat.name}".`);
      }
    }
  };

  const handleAddOrEditTransaction = (formData: Omit<Transaction, 'id'>, id?: string) => {
    let updatedTransactions: Transaction[] = [];
    if (id) {
      // Modificar existente
      updatedTransactions = transactions.map(t => {
        if (t.id === id) {
          return { ...t, ...formData };
        }
        return t;
      });
      setTransactions(updatedTransactions);
      saveTransactions(updatedTransactions);
      triggerToast('Transacción modificada correctamente');
    } else {
      // Crear nueva
      const newTransaction: Transaction = {
        ...formData,
        id: `tx-custom-${Date.now()}`
      };
      updatedTransactions = [newTransaction, ...transactions];
      setTransactions(updatedTransactions);
      saveTransactions(updatedTransactions);
      triggerToast('Nueva transacción registrada con éxito');
    }
    
    // Comprobar presupuestos en tiempo real
    if (formData.category && formData.amount > 0) {
      setTimeout(() => {
        checkBudgetAlertOnAddition(formData.category, formData.amount, updatedTransactions);
      }, 400);
    }
    
    // Cerrar modal
    setShowTransactionModal(false);
    setEditingTransaction(null);
  };

  const handleDeleteTransaction = (id: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar permanentemente este registro?')) {
      const updated = transactions.filter(t => t.id !== id);
      setTransactions(updated);
      saveTransactions(updated);
      triggerToast('Transacción eliminada de la base de datos', 'info');
    }
  };

  const handleEditInit = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setShowTransactionModal(true);
  };

  // 3.5. CONTROLADORES DE PRESUPUESTOS
  const handleUpdateBudget = (categoryId: string, amount: number) => {
    let updated: Budget[];
    const exists = budgets.some(b => b.categoryId === categoryId);
    if (exists) {
      updated = budgets.map(b => b.categoryId === categoryId ? { ...b, amount } : b);
    } else {
      updated = [...budgets, { categoryId, amount }];
    }
    setBudgets(updated);
    saveBudgets(updated);
    
    const cat = categories.find(c => c.id === categoryId);
    const catName = cat ? cat.name : '';
    triggerToast(amount > 0 
      ? `Presupuesto establecido para "${catName}" a ${formatCurrency(amount, currencySymbol)}`
      : `Presupuesto deshabilitado para "${catName}"`
    );
  };

  // 3. CONTROLADORES DE CATEGORÍAS
  const handleAddCategory = (catData: Omit<Category, 'id'>) => {
    const newCategory: Category = {
      ...catData,
      id: `cat_custom_${Date.now()}`
    };
    const updated = [...categories, newCategory];
    setCategories(updated);
    saveCategories(updated);
    triggerToast(`Categoría "${catData.name}" creada con éxito`);
  };

  const handleDeleteCategory = (id: string) => {
    // Comprobar si hay transacciones que dependen de esta categoría
    const isUsed = transactions.some(t => t.category === id);
    if (isUsed) {
      alert('No puedes eliminar esta categoría porque ya tiene transacciones asociadas. Por favor, cambia la categoría de estas transacciones primero.');
      return;
    }

    if (window.confirm('¿Deseas eliminar esta categoría personalizada?')) {
      const updated = categories.filter(c => c.id !== id);
      setCategories(updated);
      saveCategories(updated);
      triggerToast('Categoría personalizada removida', 'info');
    }
  };

  // 4. OPERACIONES DE PLAYGROUND / CONFIGURACIONES
  const handleResetToFactory = () => {
    if (window.confirm('Esto eliminará todas tus personalizaciones y cargará las transacciones de demostración de Mayo 2026. ¿Proceder?')) {
      localStorage.setItem('finanzas_transacciones', JSON.stringify(INITIAL_TRANSACTIONS));
      localStorage.setItem('finanzas_categorias', JSON.stringify(DEFAULT_CATEGORIES));
      setTransactions(INITIAL_TRANSACTIONS);
      setCategories(DEFAULT_CATEGORIES);
      triggerToast('Aplicación restablecida a valores iniciales de fábrica');
    }
  };

  const handleClearAllData = () => {
    if (window.confirm('⚠️ ADVERTENCIA: Se borrarán permanentemente TODAS tus transacciones y categorías. Se inicializará vacío. ¿Estás seguro?')) {
      localStorage.setItem('finanzas_transacciones', JSON.stringify([]));
      setTransactions([]);
      triggerToast('Se han purgado todos los registros de la base de datos', 'info');
    }
  };

  const handleCurrencyChange = (sym: string) => {
    setCurrencySymbol(sym);
    localStorage.setItem('finanzas_pref_moneda', sym);
    triggerToast(`Moneda de visualización cambiada a: ${sym}`);
  };

  // 5. CÁLCULO DE VALORES DE RESUMEN GLOBAL (Mayo 2026 o Global)
  const globalSummary = useMemo(() => {
    return calculateTotals(transactions);
  }, [transactions]);

  // 6. CÁLCULO DE ALERTAS DE PRESUPUESTO EN TIEMPO REAL
  const activeAlerts = useMemo(() => {
    const currentYear = 2026;
    const currentMonthNum = 5; // Mayo
    
    const currTx = transactions.filter(t => {
      if (!t.date) return false;
      const [y, m] = t.date.split('-').map(Number);
      return y === currentYear && m === currentMonthNum;
    });

    return categories
      .map(cat => {
        const b = budgets.find(bg => bg.categoryId === cat.id);
        if (!b || b.amount <= 0) return null;

        const totalSpent = currTx
          .filter(t => t.category === cat.id)
          .reduce((sum, t) => sum + t.amount, 0);

        const percentage = (totalSpent / b.amount) * 100;

        if (cat.type === 'gasto') {
          if (percentage >= 100) {
            return {
              id: cat.id,
              type: 'danger' as const,
              percentage,
              totalSpent,
              amount: b.amount,
              message: `¡Límite excedido! Has gastado el ${percentage.toFixed(0)}% (${formatCurrency(totalSpent, currencySymbol)}) de tu límite de ${formatCurrency(b.amount, currencySymbol)} en "${cat.name}".`,
              categoryName: cat.name,
              color: cat.color
            };
          } else if (percentage >= 80) {
            return {
              id: cat.id,
              type: 'warning' as const,
              percentage,
              totalSpent,
              amount: b.amount,
              message: `¡Tope cercano! Consumo del ${percentage.toFixed(0)}% (${formatCurrency(totalSpent, currencySymbol)}) de tu límite de ${formatCurrency(b.amount, currencySymbol)} en "${cat.name}".`,
              categoryName: cat.name,
              color: cat.color
            };
          }
        }
        return null;
      })
      .filter((alert): alert is NonNullable<typeof alert> => alert !== null);
  }, [transactions, categories, budgets, currencySymbol]);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-indigo-600 selection:text-white pb-20">
      
      {/* HEADER DE LA BANDA TOP */}
      <header className="bg-white border-b border-slate-200/80 sticky top-0 z-20 backdrop-blur-md bg-white/90">
        <div className="max-w-6xl mx-auto px-4 py-4.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-md shadow-indigo-600/20 active:scale-95 transition-transform cursor-pointer">
              <Wallet size={20} strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-base font-black tracking-tight text-slate-900 uppercase">Control de Gastos</h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-0.5">Gestor Financiero</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Símbolos de Moneda */}
            <div className="hidden sm:flex bg-slate-100/80 border border-slate-200 rounded-xl p-0.5 text-xs font-bold text-slate-500">
              {['$', '€', '£', '¥'].map(symbol => (
                <button
                  key={symbol}
                  onClick={() => handleCurrencyChange(symbol)}
                  className={`w-7 h-7 rounded-lg transition-all text-center flex items-center justify-center cursor-pointer ${
                    currencySymbol === symbol
                      ? 'bg-white shadow-xs text-indigo-600 border border-slate-200/40 font-extrabold'
                      : 'hover:text-slate-900 hover:bg-slate-200/50'
                  }`}
                >
                  {symbol}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2.5 hover:bg-slate-50 rounded-xl border border-slate-200 text-slate-500 hover:text-slate-900 hover:border-slate-350 transition-all cursor-pointer"
              title="Ajustes y Playground"
            >
              <Settings size={18} />
            </button>
          </div>
        </div>
      </header>

      {/* COMPONENTE TOAST DE NOTIFICACIÓN TEMPORAL */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900/95 backdrop-blur-md text-white px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-3 border border-slate-800 animate-fade-in-up">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-bold tracking-wide text-slate-100">{toast.message}</span>
          <button onClick={() => setToast(null)} className="text-white/40 hover:text-white text-sm ml-1.5 font-bold cursor-pointer">×</button>
        </div>
      )}

      {/* ÁREA DE CONTENIDO */}
      <main className="max-w-6xl mx-auto px-4 mt-6 space-y-6">
        
        {/* PANEL LATERAL DE AJUSTES DESPLEGABLES */}
        {showSettings && (
          <div className="bg-white rounded-2xl border border-indigo-100 p-6 shadow-xs space-y-5 animate-fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-black text-indigo-900 flex items-center gap-2 uppercase tracking-wider">
                ⚙️ Ajustes y Caja de Arena (Sandbox)
              </span>
              <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-650 cursor-pointer">
                <X size={15} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600">
              {/* Moneda en móviles / select */}
              <div className="space-y-2">
                <p className="font-bold text-slate-700">Cambiar moneda principal</p>
                <div className="flex gap-2">
                  {['$', '€', '£', '¥'].map(symbol => (
                    <button
                      key={symbol}
                      onClick={() => handleCurrencyChange(symbol)}
                      className={`flex-1 py-2 border rounded-xl font-bold transition-all text-center cursor-pointer ${
                        currencySymbol === symbol
                          ? 'border-indigo-600 bg-indigo-600 text-white shadow-sm'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                      }`}
                    >
                      {symbol}
                    </button>
                  ))}
                </div>
              </div>

              {/* Controles de datos */}
              <div className="space-y-2">
                <p className="font-bold text-slate-700">Reiniciar o restaurar base de datos</p>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={handleResetToFactory}
                    className="w-full text-left py-2 px-3.5 border border-indigo-100 hover:bg-slate-50 rounded-xl text-indigo-900 font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw size={12} className="text-indigo-500" /> Cargar datos muestra de Mayo 2026
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <p className="font-bold text-rose-700">Zona peligrosa</p>
                <button
                  onClick={handleClearAllData}
                  className="w-full text-left py-2 px-3.5 border border-rose-100 hover:bg-rose-50 text-rose-650 rounded-xl font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <AlertTriangle size={12} className="text-rose-500" /> Purgar todo e iniciar vacío
                </button>
              </div>
            </div>
          </div>
        )}

        {/* HERO BANNER & BALANCES TOTALES ACUMULADOS */}
        <section className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
          {/* Fondo sutil degradado decorativo pero sobrio */}
          <div className="absolute top-0 right-0 w-84 h-84 bg-indigo-500 rounded-full blur-[110px] opacity-25 -mr-16 -mt-16 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-60 h-60 bg-indigo-900 rounded-full blur-[90px] opacity-15 -ml-16 -mb-16 pointer-events-none" />

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
            <div>
              <span className="text-[10px] bg-slate-800/80 text-indigo-300 border border-slate-700/60 font-black px-3 py-1.5 rounded-full uppercase tracking-widest font-sans inline-block">
                Balance General Acumulado
              </span>
              <h2 className="text-4xl sm:text-5xl font-extrabold mt-4 tracking-tight font-mono text-slate-50">
                {formatCurrency(globalSummary.balance, currencySymbol)}
              </h2>
              <p className="text-xs text-slate-400 mt-2.5 font-medium">
                Suma total de todos los semestres registrados en el sistema ({transactions.length} registros).
              </p>
            </div>

            {/* Acciones principales rápidas */}
            <div className="flex flex-wrap sm:flex-nowrap gap-3">
              <button
                onClick={() => {
                  setEditingTransaction(null);
                  setShowTransactionModal(true);
                }}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-5.5 rounded-2xl text-xs font-black shadow-lg shadow-indigo-600/10 transition-all hover:scale-[1.01] active:scale-95 uppercase tracking-wider cursor-pointer"
              >
                <Plus size={16} strokeWidth={3} /> Añadir Movimiento
              </button>
              <button
                onClick={() => setShowCategoryModal(true)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-755 text-slate-100 hover:text-white py-3 px-5.5 rounded-2xl text-xs font-bold border border-slate-700/90 transition-all hover:scale-[1.01] active:scale-95 uppercase tracking-wider cursor-pointer"
              >
                <Tag size={15} /> Categorías
              </button>
            </div>
          </div>

          {/* Sub-Bento Mini stats en el Banner */}
          <div className="grid grid-cols-2 gap-4 mt-8 pt-6 border-t border-slate-850 relative z-10">
            <div className="bg-slate-850/40 p-4 rounded-2xl border border-slate-800/60">
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest flex items-center gap-1.5 leading-none">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
                Ingresos Históricos
              </p>
              <h4 className="text-lg sm:text-xl font-bold text-emerald-400 mt-2.5 font-mono">
                +{formatCurrency(globalSummary.ingresos, currencySymbol)}
              </h4>
            </div>
            <div className="bg-slate-850/40 p-4 rounded-2xl border border-slate-800/60">
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest flex items-center gap-1.5 leading-none">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 inline-block animate-pulse" />
                Gastos Históricos
              </p>
              <h4 className="text-lg sm:text-xl font-bold text-rose-400 mt-2.5 font-mono">
                -{formatCurrency(globalSummary.gastos, currencySymbol)}
              </h4>
            </div>
          </div>
        </section>

        {/* COMPONENTE DE NOTIFICACIONES DE PRESUPUESTO EN TIEMPO REAL */}
        {activeAlerts.length > 0 && (
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 flex gap-3 shadow-3xs animate-fade-in">
            <div className="p-2 bg-amber-100 rounded-xl text-amber-800 shrink-0 h-10 w-10 flex items-center justify-center">
              <Bell className="w-5 h-5 animate-pulse text-amber-600" />
            </div>
            <div className="flex-1 space-y-1.5">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-amber-900 uppercase tracking-wide flex items-center gap-1.5">
                  Notificaciones de Presupuesto
                </h4>
                <span className="text-[9px] font-black bg-amber-200/60 text-amber-850 px-2 py-0.5 rounded-md uppercase">
                  {activeAlerts.length} {activeAlerts.length === 1 ? 'Alerta' : 'Alertas'}
                </span>
              </div>
              <div className="space-y-1">
                {activeAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-center gap-2 text-slate-700 text-xs"
                  >
                    <span
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{ backgroundColor: alert.color }}
                    />
                    <p className="font-medium">
                      <strong className="text-slate-900 font-bold">{alert.categoryName}:</strong> {alert.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CONTENEDOR DE SECCIONES (TABS HISTORIAL VS INFORMES) */}
        <section className="space-y-6">
          {/* Toggles de Navegación del Dashboard */}
          <div className="flex bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200/60 w-fit max-w-full gap-1">
            <button
              onClick={() => setActiveTab('historial')}
              className={`py-2 px-5 rounded-xl text-xs font-bold uppercase tracking-wider select-none transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'historial'
                  ? 'bg-white shadow-xs text-slate-900 border border-slate-200/40 font-black'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              📋 Historial y Filtros
            </button>
            <button
              onClick={() => setActiveTab('informes')}
              className={`py-2 px-5 rounded-xl text-xs font-bold uppercase tracking-wider select-none transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'informes'
                  ? 'bg-white shadow-xs text-slate-900 border border-slate-200/40 font-black'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              📈 Informes de Rendimiento
            </button>
            <button
              onClick={() => setActiveTab('presupuestos')}
              className={`py-2 px-5 rounded-xl text-xs font-bold uppercase tracking-wider select-none transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'presupuestos'
                  ? 'bg-white shadow-xs text-slate-900 border border-slate-200/40 font-black'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              🎯 Presupuestos
            </button>
          </div>

          {/* Vistas */}
          <div className="focus-outline-none">
            {activeTab === 'historial' && (
              <TransactionList
                transactions={transactions}
                categories={categories}
                onEditTransaction={handleEditInit}
                onDeleteTransaction={handleDeleteTransaction}
                currencySymbol={currencySymbol}
              />
            )}
            {activeTab === 'informes' && (
              <ReportView
                transactions={transactions}
                categories={categories}
                currencySymbol={currencySymbol}
              />
            )}
            {activeTab === 'presupuestos' && (
              <BudgetManager
                categories={categories}
                transactions={transactions}
                budgets={budgets}
                onUpdateBudget={handleUpdateBudget}
                currencySymbol={currencySymbol}
              />
            )}
          </div>
        </section>

      </main>

      {/* MODAL: REGISTRAR / EDITAR TRANSACCIÓN */}
      {showTransactionModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-lg animate-fade-in-scale">
            <TransactionForm
              categories={categories}
              onSubmit={handleAddOrEditTransaction}
              onCancel={() => {
                setShowTransactionModal(false);
                setEditingTransaction(null);
              }}
              editingTransaction={editingTransaction}
            />
          </div>
        </div>
      )}

      {/* MODAL: ADMINISTRAR CATEGORÍAS */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-lg animate-fade-in-scale">
            <CategoryManager
              categories={categories}
              onAddCategory={handleAddCategory}
              onDeleteCategory={handleDeleteCategory}
              onClose={() => setShowCategoryModal(false)}
            />
          </div>
        </div>
      )}

      {/* FOOTER GENERAL */}
      <footer className="mt-20 text-center text-[10px] text-slate-400 font-medium">
        <p>Control de Gastos &copy; 2026. Almacenamiento local automático 100% privado y seguro.</p>
        <p className="mt-1 text-slate-350">Diseñado con enfoque de alto rendimiento, React, Tailwind CSS y Lucide Icons.</p>
      </footer>

    </div>
  );
}
