import { Transaction, Category } from '../types';

// Formatear moneda (Euro o Dólar) - Español
export function formatCurrency(amount: number, currencySymbol: string = '$'): string {
  return `${currencySymbol}${amount.toLocaleString('es-ES', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

// Obtener nombre del mes en español
export function getMonthName(monthIndex: number): string {
  const months = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];
  return months[monthIndex] || '';
}

// Obtener fecha legible (ej: 19 de Mayo, 2026)
export function formatDateFriendly(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const months = [
    'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
    'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'
  ];
  return `${day} de ${months[month - 1]}, ${year}`;
}

// Obtener día de la semana largo
export function getDayOfWeekName(dateStr: string): string {
  const days = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const date = new Date(dateStr + 'T00:00:00');
  return days[date.getDay()];
}

// Obtener lunes de la semana para un YYYY-MM-DD dado
export function getStartOfWeek(dateStr: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1); // Ajustar para que el lunes sea el primer día
  const monday = new Date(date.setDate(diff));
  return formatDateString(monday);
}

// Formatear Date a YYYY-MM-DD
export function formatDateString(date: Date): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// Obtener los límites de la semana actual (Lunes a Domingo)
export function getWeekRange(dateStr: string): { start: string; end: string } {
  const startStr = getStartOfWeek(dateStr);
  const startDate = new Date(startStr + 'T00:00:00');
  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + 6);
  return {
    start: startStr,
    end: formatDateString(endDate)
  };
}

// Obtener las últimas N semanas para reportes de tendencias
export function getLastNWeeks(endDateStr: string, n: number = 4): { start: string; end: string }[] {
  const weeks: { start: string; end: string }[] = [];
  let currentMonday = new Date(getStartOfWeek(endDateStr) + 'T00:00:00');

  for (let i = 0; i < n; i++) {
    const monday = new Date(currentMonday);
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    
    weeks.unshift({
      start: formatDateString(monday),
      end: formatDateString(sunday)
    });

    // Retroceder una semana
    currentMonday.setDate(currentMonday.getDate() - 7);
  }

  return weeks;
}

// Obtener los últimos N meses para reportes de tendencias
export function getLastNMonths(year: number, month: number, n: number = 6): { year: number; month: number }[] {
  const months: { year: number; month: number }[] = [];
  let currYear = year;
  let currMonth = month; // 0-based

  for (let i = 0; i < n; i++) {
    months.unshift({ year: currYear, month: currMonth });
    currMonth--;
    if (currMonth < 0) {
      currMonth = 11;
      currYear--;
    }
  }

  return months;
}

// Calcular estadísticas globales
export function calculateTotals(transactions: Transaction[]) {
  let ingresos = 0;
  let gastos = 0;
  
  transactions.forEach(t => {
    if (t.type === 'ingreso') {
      ingresos += t.amount;
    } else {
      gastos += t.amount;
    }
  });

  return {
    ingresos,
    gastos,
    balance: ingresos - gastos
  };
}

// Filtrar transacciones por rango de fechas
export function filterByDateRange(transactions: Transaction[], start: string, end: string): Transaction[] {
  return transactions.filter(t => t.date >= start && t.date <= end);
}

// Agrupar transacciones por categoría y calcular montos
export interface CategoryAggregate {
  categoryId: string;
  categoryName: string;
  color: string;
  icon: string;
  total: number;
  percentage: number;
}

export function aggregateByCategory(
  transactions: Transaction[],
  categories: Category[],
  type: 'ingreso' | 'gasto'
): CategoryAggregate[] {
  const filtered = transactions.filter(t => t.type === type);
  const totalSum = filtered.reduce((sum, t) => sum + t.amount, 0);
  
  const categoryTotals: Record<string, number> = {};
  filtered.forEach(t => {
    categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
  });

  const aggregates: CategoryAggregate[] = [];
  categories
    .filter(cat => cat.type === type)
    .forEach(cat => {
      const total = categoryTotals[cat.id] || 0;
      if (total > 0) {
        aggregates.push({
          categoryId: cat.id,
          categoryName: cat.name,
          color: cat.color,
          icon: cat.icon,
          total,
          percentage: totalSum > 0 ? (total / totalSum) * 100 : 0
        });
      }
    });

  // Ordenar por total de mayor a menor
  return aggregates.sort((a, b) => b.total - a.total);
}
