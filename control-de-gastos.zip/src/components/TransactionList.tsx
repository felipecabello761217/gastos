import { useState, useMemo } from 'react';
import { Transaction, Category } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { formatDateFriendly, getDayOfWeekName, formatCurrency } from '../utils/financeUtils';
import { Search, Edit3, Trash2, SlidersHorizontal, RefreshCw, Layers, ArrowUpDown, Tag } from 'lucide-react';

interface TransactionListProps {
  transactions: Transaction[];
  categories: Category[];
  onEditTransaction: (transaction: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
  currencySymbol: string;
}

type SortOption = 'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc';

export function TransactionList({
  transactions,
  categories,
  onEditTransaction,
  onDeleteTransaction,
  currencySymbol
}: TransactionListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'todos' | 'ingreso' | 'gasto'>('todos');
  const [categoryFilter, setCategoryFilter] = useState<string>('todas');
  const [sortOption, setSortOption] = useState<SortOption>('date-desc');
  const [visibleCount, setVisibleCount] = useState<number>(12); // Paginación "Ver más"

  // Reiniciar filtros
  const handleResetFilters = () => {
    setSearchTerm('');
    setTypeFilter('todos');
    setCategoryFilter('todas');
    setSortOption('date-desc');
    setVisibleCount(12);
  };

  // 1. FILTER & SEARCH
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      // Búsqueda textual
      const descMatch = t.description.toLowerCase().includes(searchTerm.toLowerCase());
      const notesMatch = t.notes?.toLowerCase().includes(searchTerm.toLowerCase()) || false;
      const textMatch = descMatch || notesMatch;

      // Filtro de tipo
      const typeMatch = typeFilter === 'todos' || t.type === typeFilter;

      // Filtro de categoría
      const categoryMatch = categoryFilter === 'todas' || t.category === categoryFilter;

      return textMatch && typeMatch && categoryMatch;
    });
  }, [transactions, searchTerm, typeFilter, categoryFilter]);

  // 2. SORTING
  const sortedTransactions = useMemo(() => {
    const list = [...filteredTransactions];
    
    switch (sortOption) {
      case 'date-desc':
        return list.sort((a, b) => b.date.localeCompare(a.date));
      case 'date-asc':
        return list.sort((a, b) => a.date.localeCompare(b.date));
      case 'amount-desc':
        return list.sort((a, b) => b.amount - a.amount);
      case 'amount-asc':
        return list.sort((a, b) => a.amount - b.amount);
      default:
        return list;
    }
  }, [filteredTransactions, sortOption]);

  // Transacciones visibles con paginación
  const visibleTransactions = useMemo(() => {
    return sortedTransactions.slice(0, visibleCount);
  }, [sortedTransactions, visibleCount]);

  // 3. AGRUPACIÓN POR FECHAS (Solo si estamos ordenados en base a fecha)
  const isDateSorted = sortOption === 'date-desc' || sortOption === 'date-asc';

  interface DayGroup {
    date: string;
    transactions: Transaction[];
    dailyBalance: number;
  }

  const groupedByDay = useMemo(() => {
    if (!isDateSorted) return [];

    const groups: DayGroup[] = [];
    
    visibleTransactions.forEach(t => {
      let existingGroup = groups.find(g => g.date === t.date);
      if (!existingGroup) {
        existingGroup = {
          date: t.date,
          transactions: [],
          dailyBalance: 0
        };
        groups.push(existingGroup);
      }
      existingGroup.transactions.push(t);
      if (t.type === 'ingreso') {
        existingGroup.dailyBalance += t.amount;
      } else {
        existingGroup.dailyBalance -= t.amount;
      }
    });

    return groups;
  }, [visibleTransactions, isDateSorted]);

  // Obtener nombre de la categoría mapeada por ID
  const getCategoryDetails = (catId: string) => {
    return categories.find(c => c.id === catId) || {
      name: 'Sin categoría',
      color: '#9ca3af',
      icon: 'HelpCircle'
    };
  };

  return (
    <div className="space-y-5 font-sans">
      {/* Contenedor de Filtros Avanzados */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row gap-3.5">
          {/* Barra de Búsqueda */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Buscar transacción por descripción o notas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none bg-slate-50/25 transition-all"
            />
          </div>

          {/* Filtro Tipo de Transacción */}
          <div className="flex bg-slate-100/90 rounded-xl p-1 shrink-0">
            <button
              onClick={() => setTypeFilter('todos')}
              className={`py-1.5 px-4 rounded-lg text-xs font-bold select-none transition-all cursor-pointer ${
                typeFilter === 'todos' ? 'bg-white shadow-3xs text-slate-900 font-extrabold border border-slate-200/30' : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setTypeFilter('ingreso')}
              className={`py-1.5 px-4 rounded-lg text-xs font-bold select-none transition-all cursor-pointer ${
                typeFilter === 'ingreso' ? 'bg-white shadow-3xs text-emerald-600 font-extrabold border border-slate-200/30' : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              Ingresos
            </button>
            <button
              onClick={() => setTypeFilter('gasto')}
              className={`py-1.5 px-4 rounded-lg text-xs font-bold select-none transition-all cursor-pointer ${
                typeFilter === 'gasto' ? 'bg-white shadow-3xs text-rose-600 font-extrabold border border-slate-200/30' : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              Gastos
            </button>
          </div>
        </div>

        {/* Fila de filtros complementarios (Categoría, Orden, Reinicio) */}
        <div className="flex flex-col sm:flex-row flex-wrap gap-4 items-center justify-between pt-3 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap gap-3.5 items-center w-full sm:w-auto">
            {/* Categoría Dropdown */}
            <div className="flex items-center gap-1.5 w-full sm:w-auto">
              <Tag size={13} className="text-slate-400" />
              <span className="text-slate-500 font-semibold text-xs">Categoría:</span>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-bold focus:border-indigo-500 focus:outline-none cursor-pointer transition-all"
              >
                <option value="todas">Todas las categorías</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>
                    {cat.type === 'ingreso' ? '📊' : '💸'} {cat.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Ordenamiento */}
            <div className="flex items-center gap-1.5 w-full sm:w-auto">
              <ArrowUpDown size={13} className="text-slate-400" />
              <span className="text-slate-500 font-semibold text-xs">Ordenar por:</span>
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value as SortOption)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-bold focus:border-indigo-500 focus:outline-none cursor-pointer transition-all"
              >
                <option value="date-desc">Más recientes primero</option>
                <option value="date-asc">Más antiguas primero</option>
                <option value="amount-desc">Mayor cantidad</option>
                <option value="amount-asc">Menor cantidad</option>
              </select>
            </div>
          </div>

          {/* Botón resetear */}
          {(searchTerm || typeFilter !== 'todos' || categoryFilter !== 'todas' || sortOption !== 'date-desc') && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 transition-colors w-full sm:w-auto justify-center cursor-pointer font-semibold"
            >
              <RefreshCw size={12} className="text-slate-500" />
              Limpiar filtros
            </button>
          )}
        </div>
      </div>

      {/* RESULTADO CONTADOR */}
      <div className="flex justify-between items-center px-1 text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">
        <span>Transacciones encontradas ({filteredTransactions.length})</span>
        {filteredTransactions.length > visibleCount && (
          <span>Mostrando {visibleCount} de {filteredTransactions.length}</span>
        )}
      </div>

      {/* CUERPO DE LA LISTA */}
      {filteredTransactions.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-3xs">
          <span className="text-4xl mb-3 block">🔍</span>
          <h4 className="text-sm font-black text-slate-800">No se encontraron transacciones</h4>
          <p className="text-xs text-slate-450 mt-1.5 max-w-xs mx-auto">
            Intenta cambiar los términos de búsqueda o ajustar las categorías o filtros de la parte superior.
          </p>
          <button
            onClick={handleResetFilters}
            className="mt-4 px-5 py-2.5 border border-slate-350 hover:border-slate-800 bg-white rounded-xl text-xs font-bold text-slate-700 hover:text-slate-900 transition-colors cursor-pointer active:scale-95"
          >
            Saldar filtros
          </button>
        </div>
      ) : isDateSorted ? (
        /* AGRUPADO POR FECHAS (DISEÑO MÓVIL Y BANCA DE ÉLITE) */
        <div className="space-y-6">
          {groupedByDay.map(group => (
            <div key={group.date} className="space-y-2.5">
              {/* Header de fecha con saldo diario */}
              <div className="flex items-center justify-between bg-slate-100 p-3 rounded-2xl px-4.5 border border-slate-200/60">
                <div className="flex flex-col">
                  <span className="text-xs font-extrabold text-slate-800">
                    {formatDateFriendly(group.date)}
                  </span>
                  <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider mt-0.5">
                    {getDayOfWeekName(group.date)}
                  </span>
                </div>
                <div className="text-right">
                  <span className={`text-xs font-black font-mono ${
                    group.dailyBalance > 0 ? 'text-emerald-700' : group.dailyBalance < 0 ? 'text-rose-600' : 'text-slate-500'
                  }`}>
                    Saldo del día: {group.dailyBalance > 0 ? '+' : ''}{formatCurrency(group.dailyBalance, currencySymbol)}
                  </span>
                </div>
              </div>

              {/* Transacciones de este día */}
              <div className="space-y-2 pl-1 sm:pl-2">
                {group.transactions.map(t => {
                  const cat = getCategoryDetails(t.category);
                  return (
                    <div
                      key={t.id}
                      className="bg-white rounded-2xl p-4.5 border border-slate-200/80 hover:border-slate-300 hover:shadow-xs transition-all flex items-center justify-between gap-4"
                    >
                      {/* Icono + Nombre + Fecha */}
                      <div className="flex items-center gap-3.5 min-w-0 flex-1">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-3xs"
                          style={{ backgroundColor: cat.color }}
                        >
                          <CategoryIcon name={cat.icon} size={18} />
                        </div>

                        <div className="min-w-0">
                          <p className="text-sm font-bold text-slate-900 truncate">
                            {t.description}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[10px] px-2 py-0.5 rounded-md text-slate-600 font-extrabold bg-slate-100/60 border border-slate-200/40">
                              {cat.name}
                            </span>
                            {t.notes && (
                              <span className="text-[10px] text-slate-450 font-semibold truncate max-w-[120px] sm:max-w-[200px]" title={t.notes}>
                                📝 {t.notes}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Monto + Acciones de Edición/Eliminación */}
                      <div className="flex items-center gap-4 shrink-0">
                        <span className={`text-sm font-black text-right font-mono ${
                          t.type === 'ingreso' ? 'text-emerald-600' : 'text-slate-900'
                        }`}>
                          {t.type === 'ingreso' ? '+' : '-'}{formatCurrency(t.amount, currencySymbol)}
                        </span>

                        <div className="flex items-center gap-1.5 border-l border-slate-200 pl-3">
                          <button
                            onClick={() => onEditTransaction(t)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                            title="Editar transacción"
                          >
                            <Edit3 size={14} />
                          </button>
                          <button
                            onClick={() => onDeleteTransaction(t.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Eliminar transacción"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* SIMPLE TABULAR LIST (Si no ordenamos por fecha, ej: por monto) */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-3xs overflow-hidden">
          <div className="divide-y divide-slate-100">
            {visibleTransactions.map(t => {
              const cat = getCategoryDetails(t.category);
              return (
                <div
                  key={t.id}
                  className="p-4 hover:bg-slate-50/50 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: cat.color }}
                    >
                      <CategoryIcon name={cat.icon} size={16} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-800 truncate">{t.description}</p>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                        <span className="font-extrabold text-slate-650 bg-slate-100 px-1.5 py-0.5 rounded-md">{cat.name}</span>
                        <span>•</span>
                        <span>{formatDateFriendly(t.date)}</span>
                        {t.notes && (
                          <>
                            <span>•</span>
                            <span className="truncate max-w-[120px] sm:max-w-xs">📝 {t.notes}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    <span className={`text-xs font-black font-mono ${
                      t.type === 'ingreso' ? 'text-emerald-600' : 'text-slate-900'
                    }`}>
                      {t.type === 'ingreso' ? '+' : '-'}{formatCurrency(t.amount, currencySymbol)}
                    </span>
                    <div className="flex items-center gap-1.5 border-l border-slate-200 pl-2">
                      <button
                        onClick={() => onEditTransaction(t)}
                        className="p-1.5 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded-lg transition-all cursor-pointer"
                      >
                        <Edit3 size={13} />
                      </button>
                      <button
                        onClick={() => onDeleteTransaction(t.id)}
                        className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-all cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VER MÁS BOTÓN */}
      {sortedTransactions.length > visibleCount && (
        <div className="flex justify-center pt-3">
          <button
            onClick={() => setVisibleCount(count => count + 12)}
            className="px-6 py-2.5 rounded-2xl border border-slate-200 text-xs font-extrabold text-slate-600 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 transition-all flex items-center gap-2 bg-white cursor-pointer active:scale-95"
          >
            <span>✨ Ver más transacciones</span>
          </button>
        </div>
      )}
    </div>
  );
}
