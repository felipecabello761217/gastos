import React, { useState, useEffect } from 'react';
import { Transaction, Category } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { X, Check } from 'lucide-react';

interface TransactionFormProps {
  categories: Category[];
  onSubmit: (transactionData: Omit<Transaction, 'id'>, id?: string) => void;
  onCancel: () => void;
  editingTransaction?: Transaction | null;
}

export function TransactionForm({
  categories,
  onSubmit,
  onCancel,
  editingTransaction
}: TransactionFormProps) {
  const [type, setType] = useState<'gasto' | 'ingreso'>('gasto');
  const [amount, setAmount] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');

  // Sincronizar campos si estamos editando
  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAmount(editingTransaction.amount.toString());
      setCategoryId(editingTransaction.category);
      setDate(editingTransaction.date);
      setDescription(editingTransaction.description);
      setNotes(editingTransaction.notes || '');
    } else {
      // Valor por defecto hoy
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const dd = String(today.getDate()).padStart(2, '0');
      setDate(`${yyyy}-${mm}-${dd}`);
      
      // Auto-seleccionar primer categoría disponible para 'gasto'
      const expenseCats = categories.filter(c => c.type === 'gasto');
      if (expenseCats.length > 0) {
        setCategoryId(expenseCats[0].id);
      }
    }
  }, [editingTransaction, categories]);

  // Si cambia el tipo, reajustar categoría por defecto
  const handleTypeChange = (newType: 'gasto' | 'ingreso') => {
    setType(newType);
    const filteredCats = categories.filter(c => c.type === newType);
    if (filteredCats.length > 0) {
      // Intentar mantener selección si existe en el nuevo tipo, si no, usar la primera
      const exists = filteredCats.some(c => c.id === categoryId);
      if (!exists) {
        setCategoryId(filteredCats[0].id);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Por favor, ingresa un monto válido mayor que cero.');
      return;
    }

    if (!categoryId) {
      setError('Por favor, selecciona una categoría.');
      return;
    }

    if (!date) {
      setError('Por favor, selecciona una fecha.');
      return;
    }

    if (!description.trim()) {
      setError('Por favor, introduce una descripción descriptiva.');
      return;
    }

    onSubmit(
      {
        type,
        amount: parsedAmount,
        category: categoryId,
        date,
        description: description.trim(),
        notes: notes.trim() || undefined
      },
      editingTransaction?.id
    );
  };

  const filteredCategories = categories.filter(cat => cat.type === type);

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 max-w-lg w-full mx-auto font-sans">
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-950 font-sans tracking-tight">
          {editingTransaction ? 'Editar Transacción' : 'Nueva Transacción'}
        </h3>
        <button
          onClick={onCancel}
          className="text-gray-400 hover:text-gray-600 transition-colors p-1.5 rounded-full hover:bg-gray-100"
          type="button"
        >
          <X size={18} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Selector de tipo (Gasto / Ingreso) */}
        <div className="grid grid-cols-2 gap-2 bg-gray-50 p-1.5 rounded-xl">
          <button
            type="button"
            onClick={() => handleTypeChange('gasto')}
            className={`py-2.5 px-4 text-sm font-medium rounded-lg transition-all text-center ${
              type === 'gasto'
                ? 'bg-red-500 text-white shadow-sm shadow-red-100'
                : 'text-gray-500 hover:text-gray-900 hover:bg-white/50'
            }`}
          >
            📉 Gasto
          </button>
          <button
            type="button"
            onClick={() => handleTypeChange('ingreso')}
            className={`py-2.5 px-4 text-sm font-medium rounded-lg transition-all text-center ${
              type === 'ingreso'
                ? 'bg-green-500 text-white shadow-sm shadow-green-100'
                : 'text-gray-500 hover:text-gray-900 hover:bg-white/50'
            }`}
          >
            📈 Ingreso
          </button>
        </div>

        {/* Monto principal */}
        <div className="relative">
          <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1.5">
            Monto / Cantidad
          </label>
          <div className="relative flex items-center rounded-xl border border-gray-200 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-100 transition-all overflow-hidden bg-white">
            <span className="pl-4 text-2xl font-semibold text-gray-400">$</span>
            <input
              type="number"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full pl-2 pr-4 py-3 text-2xl font-bold text-gray-900 border-none outline-none focus:ring-0"
              autoFocus={!editingTransaction}
              required
            />
          </div>
        </div>

        {/* Descripción corta */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1.5">
            Descripción
          </label>
          <input
            type="text"
            placeholder="ej.: Compra súper, Pago de internet, Salario quincenal"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-gray-900 text-sm placeholder-gray-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
            required
          />
        </div>

        {/* Categorías (Bento Grid Mini o Dropdown optimizado) */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1.5">
            Categoría
          </label>
          <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto p-1 border border-gray-100 rounded-xl bg-gray-50/50">
            {filteredCategories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategoryId(cat.id)}
                className={`flex items-center gap-2.5 p-2 rounded-lg text-left transition-all border ${
                  categoryId === cat.id
                    ? 'bg-white border-zinc-900 shadow-sm text-zinc-950 scale-[1.01]'
                    : 'bg-white/40 border-gray-200 text-gray-600 hover:bg-white hover:border-gray-300'
                }`}
              >
                <div
                  className="w-7 h-7 rounded-md flex items-center justify-center text-white shrink-0"
                  style={{ backgroundColor: cat.color }}
                >
                  <CategoryIcon name={cat.icon} size={15} strokeWidth={2.5} />
                </div>
                <span className="text-xs font-medium truncate">{cat.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Fecha y Notas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1.5">
              Fecha de transacción
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-gray-900 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-1.5">
              Notas Adicionales (Opcional)
            </label>
            <input
              type="text"
              placeholder="Detalles, número de ticket..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-gray-900 text-sm placeholder-gray-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
            />
          </div>
        </div>

        {/* Error Feedback */}
        {error && (
          <div className="p-3.5 bg-red-50/70 border border-red-200 rounded-xl text-xs text-red-600 flex items-center gap-2">
            <span>⚠️</span>
            <span className="font-semibold">{error}</span>
          </div>
        )}

        {/* Botones de acción */}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2.5 px-4 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-all font-sans"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="flex-1 py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-white font-semibold text-sm transition-all focus:ring-2 focus:ring-zinc-650 flex items-center justify-center gap-1.5 font-sans"
          >
            <Check size={16} />
            {editingTransaction ? 'Guardar Cambios' : 'Confirmar'}
          </button>
        </div>
      </form>
    </div>
  );
}
