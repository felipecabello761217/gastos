import { useState } from 'react';
import { Transaction, Category } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { InteractivePieChart } from './InteractivePieChart';
import { InteractiveBarChart } from './InteractiveBarChart';
import {
  formatCurrency,
  formatDateFriendly,
  getMonthName,
  getWeekRange,
  getLastNWeeks,
  getLastNMonths,
  filterByDateRange,
  aggregateByCategory,
  CategoryAggregate
} from '../utils/financeUtils';
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  ChevronLeft,
  ChevronRight,
  TrendingUp as BudgetUp,
  Scale,
  Award,
  DollarSign
} from 'lucide-react';

interface ReportViewProps {
  transactions: Transaction[];
  categories: Category[];
  currencySymbol: string;
}

export function ReportView({
  transactions,
  categories,
  currencySymbol
}: ReportViewProps) {
  const [reportType, setReportType] = useState<'semanal' | 'mensual'>('mensual');
  
  // Para reporte semanal
  const [selectedWeekIndex, setSelectedWeekIndex] = useState(0); // 0 es la semana actual
  const weeksList = getLastNWeeks('2026-05-19', 5); // Obtener 5 semanas anteriores a la actual
  const currentWeekRange = weeksList[weeksList.length - 1 - selectedWeekIndex] || weeksList[weeksList.length - 1];

  // Para reporte mensual
  const [selectedMonthIndex, setSelectedMonthIndex] = useState(0); // 0 es el mes actual (Mayo)
  const monthsList = getLastNMonths(2026, 4, 4); // Obtener 4 meses anteriores a Mayo 2026
  const currentMonthPeriod = monthsList[monthsList.length - 1 - selectedMonthIndex] || monthsList[monthsList.length - 1];

  // 1. OBTENER TRANSACCIONES DEL PERIODO SELECCIONADO
  let periodTransactions: Transaction[] = [];
  let titlePeriod = '';
  let previousPeriodTransactions: Transaction[] = []; // Para cálculos comparativos

  if (reportType === 'semanal') {
    periodTransactions = filterByDateRange(
      transactions,
      currentWeekRange.start,
      currentWeekRange.end
    );
    titlePeriod = `Semana del ${formatDateFriendly(currentWeekRange.start)} al ${formatDateFriendly(currentWeekRange.end)}`;

    // Comparar con la semana anterior
    const prevWeekIndex = weeksList.length - 1 - selectedWeekIndex - 1;
    if (prevWeekIndex >= 0 && weeksList[prevWeekIndex]) {
      previousPeriodTransactions = filterByDateRange(
        transactions,
        weeksList[prevWeekIndex].start,
        weeksList[prevWeekIndex].end
      );
    }
  } else {
    // Reporte mensual
    periodTransactions = transactions.filter(t => {
      const [y, m] = t.date.split('-').map(Number);
      return y === currentMonthPeriod.year && (m - 1) === currentMonthPeriod.month;
    });
    titlePeriod = `${getMonthName(currentMonthPeriod.month)} de ${currentMonthPeriod.year}`;

    // Comparar con el mes anterior
    let prevMonth = currentMonthPeriod.month - 1;
    let prevYear = currentMonthPeriod.year;
    if (prevMonth < 0) {
      prevMonth = 11;
      prevYear--;
    }
    previousPeriodTransactions = transactions.filter(t => {
      const [y, m] = t.date.split('-').map(Number);
      return y === prevYear && (m - 1) === prevMonth;
    });
  }

  // 2. CÁLCULO DE MÉTRICAS CLAVE
  const incomeTransactions = periodTransactions.filter(t => t.type === 'ingreso');
  const expenseTransactions = periodTransactions.filter(t => t.type === 'gasto');

  const totalIncomes = incomeTransactions.reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = expenseTransactions.reduce((sum, t) => sum + t.amount, 0);
  const balance = totalIncomes - totalExpenses;

  // Tasa de Ahorro: Balance / Ingresos * 100
  const savingsRate = totalIncomes > 0 ? (balance / totalIncomes) * 100 : 0;

  // Promedio de gasto diario
  const daysInPeriod = reportType === 'semanal' ? 7 : 30;
  const averageDailyExpense = totalExpenses / daysInPeriod;

  // Agrupación por categoría
  const expenseBreakdown = aggregateByCategory(periodTransactions, categories, 'gasto');
  const incomeBreakdown = aggregateByCategory(periodTransactions, categories, 'ingreso');

  // 3. DATOS COMPARATIVOS PERIODO ANTERIOR
  const prevExpenses = previousPeriodTransactions
    .filter(t => t.type === 'gasto')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const expenseChangePercent = prevExpenses > 0 
    ? ((totalExpenses - prevExpenses) / prevExpenses) * 100 
    : 0;

  // Máximo gasto singular en el periodo
  const maxExpenseItem = expenseTransactions.length > 0
    ? [...expenseTransactions].sort((a,b) => b.amount - a.amount)[0]
    : null;

  return (
    <div className="space-y-6">
      {/* 2-Way Tab Bar and Navigators */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        {/* Toggle Semanal / Mensual */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100 rounded-xl w-full md:w-64">
          <button
            onClick={() => {
              setReportType('semanal');
              setSelectedWeekIndex(0);
            }}
            className={`py-2 px-4 rounded-lg text-xs font-bold transition-all text-center cursor-pointer ${
              reportType === 'semanal'
                ? 'bg-white text-slate-900 border border-slate-200/30 shadow-3xs font-black'
                : 'text-slate-500 hover:text-slate-950'
            }`}
          >
            🗓️ Reporte Semanal
          </button>
          <button
            onClick={() => {
              setReportType('mensual');
              setSelectedMonthIndex(0);
            }}
            className={`py-2 px-4 rounded-lg text-xs font-bold transition-all text-center cursor-pointer ${
              reportType === 'mensual'
                ? 'bg-white text-slate-900 border border-slate-200/30 shadow-3xs font-black'
                : 'text-slate-500 hover:text-slate-950'
            }`}
          >
            📊 Reporte Mensual
          </button>
        </div>

        {/* Navegador de periodos */}
        <div className="flex items-center justify-between md:justify-end gap-3 w-full md:w-auto">
          <button
            onClick={() => {
              if (reportType === 'semanal') {
                if (selectedWeekIndex < weeksList.length - 1) setSelectedWeekIndex(idx => idx + 1);
              } else {
                if (selectedMonthIndex < monthsList.length - 1) setSelectedMonthIndex(idx => idx + 1);
              }
            }}
            disabled={
              reportType === 'semanal'
                ? selectedWeekIndex >= weeksList.length - 1
                : selectedMonthIndex >= monthsList.length - 1
            }
            className="flex items-center justify-center p-2 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-950 transition-all disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
            title="Periodo anterior"
          >
            <ChevronLeft size={16} />
          </button>

          <div className="flex items-center gap-2 text-center text-xs font-bold text-slate-800 bg-slate-50 px-4 py-2 rounded-xl border border-slate-200/50">
            <Calendar size={13} className="text-slate-500" />
            <span className="truncate max-w-xs md:max-w-md">{titlePeriod}</span>
          </div>

          <button
            onClick={() => {
              if (reportType === 'semanal') {
                if (selectedWeekIndex > 0) setSelectedWeekIndex(idx => idx - 1);
              } else {
                if (selectedMonthIndex > 0) setSelectedMonthIndex(idx => idx - 1);
              }
            }}
            disabled={
              reportType === 'semanal'
                ? selectedWeekIndex === 0
                : selectedMonthIndex === 0
            }
            className="flex items-center justify-center p-2 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-950 transition-all disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
            title="Periodo posterior"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Rápida Alerta de Presupuestos u Observaciones Generales */}
      {periodTransactions.length === 0 && (
        <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
          <span className="text-3xl mb-2.5 block">📭</span>
          <h4 className="text-sm font-black text-slate-700">No hay transacciones guardadas en este periodo</h4>
          <p className="text-xs text-slate-450 mt-1.5 max-w-sm mx-auto">
            Agrega nuevas transacciones desde el panel principal seleccionando la fecha adecuada para ver este gráfico poblado.
          </p>
        </div>
      )}

      {periodTransactions.length > 0 && (
        <>
          {/* Bento-grid of Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Tarjeta de Ingresos */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ingresos totales</p>
                  <h4 className="text-2xl font-black text-slate-950 mt-1.5 font-mono">{formatCurrency(totalIncomes, currencySymbol)}</h4>
                </div>
                <div className="w-9 h-9 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                  <TrendingUp size={18} />
                </div>
              </div>
              <p className="text-[11px] text-slate-500 mt-3.5">
                Representado en <b className="font-bold text-slate-700">{incomeTransactions.length}</b> transacciones
              </p>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500" />
            </div>

            {/* Tarjeta de Gastos */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Gastos totales</p>
                  <h4 className="text-2xl font-black text-slate-950 mt-1.5 font-mono">{formatCurrency(totalExpenses, currencySymbol)}</h4>
                </div>
                <div className="w-9 h-9 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
                  <TrendingDown size={18} />
                </div>
              </div>
              
              <div className="mt-3.5 flex items-center gap-1.5 md:gap-2">
                {expenseChangePercent === 0 ? (
                  <span className="text-[10px] text-slate-405 font-bold">Sin datos del periodo anterior</span>
                ) : expenseChangePercent < 0 ? (
                  <span className="text-[10px] bg-emerald-50 text-emerald-750 font-black px-2 py-0.5 rounded-md flex items-center gap-0.5">
                    ↓ {Math.abs(expenseChangePercent).toFixed(1)}% vs anterior
                  </span>
                ) : (
                  <span className="text-[10px] bg-rose-50 text-rose-750 font-black px-2 py-0.5 rounded-md flex items-center gap-0.5">
                    ↑ {expenseChangePercent.toFixed(1)}% vs anterior
                  </span>
                )}
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-rose-500" />
            </div>

            {/* Tarjeta de Saldo */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Balance Neto</p>
                  <h4 className={`text-2xl font-black mt-1.5 font-mono ${balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {balance >= 0 ? '+' : ''}{formatCurrency(balance, currencySymbol)}
                  </h4>
                </div>
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${balance >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                  <Scale size={18} />
                </div>
              </div>
              <p className="text-[11px] text-slate-500 mt-3.5">
                {balance >= 0 ? '📈 Finanzas saludables superávit' : '⚠️ Superaste tus ingresos este lapso'}
              </p>
              <div className={`absolute bottom-0 left-0 right-0 h-1 ${balance >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
            </div>

            {/* Tarjeta de Tasa de Ahorro / Promedio Gasto */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-2xs relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tasa de ahorro</p>
                  <h4 className="text-2xl font-black text-slate-950 mt-1.5 font-mono">
                    {savingsRate > 0 ? `${savingsRate.toFixed(1)}%` : '0.0%'}
                  </h4>
                </div>
                <div className="w-9 h-9 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                  <Award size={18} />
                </div>
              </div>
              <p className="text-[11px] text-slate-500 mt-3.5">
                Gasto diario promedio: <b className="font-bold text-slate-700">{formatCurrency(averageDailyExpense, currencySymbol)}</b>
              </p>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-500" />
            </div>

          </div>

          {/* Gráfico de Tendencias e Informes de Distribución de Categorías */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            
            {/* Columna Izquierda: Desglose por categoría del gasto (3/5) */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs lg:col-span-3 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-slate-950 mb-0.5">💰 Desglose General de Gastos</h4>
                  <p className="text-xs text-slate-400">¿Hacia dónde va realmente tu dinero?</p>
                </div>
                <span className="text-[10px] font-black bg-slate-100 text-slate-600 px-3 py-1 rounded-full uppercase tracking-wider">
                  Por Categoría
                </span>
              </div>

              {expenseBreakdown.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  No se registraron egresos en esta ventana de tiempo.
                </div>
              ) : (
                <div className="pt-2">
                  <InteractivePieChart data={expenseBreakdown} currencySymbol={currencySymbol} />
                </div>
              )}
            </div>

            {/* Columna Derecha: Resumen de ingresos u otros detalles de interés (2/5) */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs lg:col-span-2 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-slate-950 mb-0.5">📥 Fuentes de Ingresos</h4>
                  <p className="text-xs text-slate-400">Tus entradas de capital registradas</p>
                </div>
                <span className="text-[10px] font-black bg-slate-100 text-slate-600 px-3 py-1 rounded-full uppercase tracking-wider">
                  Por Tipo
                </span>
              </div>

              {incomeBreakdown.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  No se registraron ingresos en esta ventana de tiempo.
                </div>
              ) : (
                <div className="space-y-3.5 pt-1">
                  {incomeBreakdown.map((item) => (
                    <div key={item.categoryId} className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-700 flex items-center gap-1.5">
                          <span
                            className="w-2.5 h-2.5 rounded-full inline-block"
                            style={{ backgroundColor: item.color }}
                          />
                          {item.categoryName}
                        </span>
                        <span className="font-extrabold text-slate-900 font-mono">
                          {formatCurrency(item.total, currencySymbol)}
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          style={{
                            width: `${item.percentage}%`,
                            backgroundColor: item.color
                          }}
                          className="h-full rounded-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Mayor Egreso del Periodo_h */}
              {maxExpenseItem && (
                <div className="p-3.5 bg-amber-50/60 border border-amber-100 rounded-xl space-y-1.5 mt-5">
                  <div className="flex items-center gap-1.5 text-xs text-amber-900 font-black">
                    <span>⚠️</span> Gasto más alto del periodo
                  </div>
                  <div className="flex justify-between items-center text-xs mt-1">
                    <span className="text-slate-700 font-bold truncate max-w-[190px]">{maxExpenseItem.description}</span>
                    <span className="font-black text-rose-650 font-mono">{formatCurrency(maxExpenseItem.amount, currencySymbol)}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium">
                    Ocurrido el día {formatDateFriendly(maxExpenseItem.date)}
                  </p>
                </div>
              )}

            </div>
          </div>

          {/* Gráfico SVG de Tendencia de Gastos en el Tiempo */}
          <div className="p-6 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div>
              <h4 className="text-sm font-black text-slate-950 mb-0.5">📈 Historial de Egresos vs Ingresos</h4>
              <p className="text-xs text-slate-400">Evolución de gastos e ingresos de los últimos periodos activos</p>
            </div>

            <div className="pt-2">
              <InteractiveBarChart
                data={
                  reportType === 'semanal'
                    ? weeksList.map((wk, i) => {
                        const wkTx = filterByDateRange(transactions, wk.start, wk.end);
                        const wkIncomes = wkTx.filter(t => t.type === 'ingreso').reduce((sum, t) => sum + t.amount, 0);
                        const wkExpenses = wkTx.filter(t => t.type === 'gasto').reduce((sum, t) => sum + t.amount, 0);
                        return {
                          label: `Sem. ${weeksList.length - i}`,
                          incomes: wkIncomes,
                          expenses: wkExpenses
                        };
                      })
                    : monthsList.map((mObj) => {
                        const mTx = transactions.filter(t => {
                          const [y, m] = t.date.split('-').map(Number);
                          return y === mObj.year && (m - 1) === mObj.month;
                        });
                        const mIncomes = mTx.filter(t => t.type === 'ingreso').reduce((sum, t) => sum + t.amount, 0);
                        const mExpenses = mTx.filter(t => t.type === 'gasto').reduce((sum, t) => sum + t.amount, 0);
                        return {
                          label: `${getMonthName(mObj.month).substring(0, 3)} '${String(mObj.year).substring(2)}`,
                          incomes: mIncomes,
                          expenses: mExpenses
                        };
                      })
                }
                currencySymbol={currencySymbol}
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
}
