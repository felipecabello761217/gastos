import { useState, useMemo } from 'react';
import { Category, Transaction, Budget } from '../types';
import { formatCurrency } from '../utils/financeUtils';
import { CategoryIcon } from './CategoryIcon';
import { AlertTriangle, CheckCircle, Flame, Plus, Pencil, Check, X, ShieldAlert, Sparkles, AlertCircle } from 'lucide-react';

interface BudgetManagerProps {
  categories: Category[];
  transactions: Transaction[];
  budgets: Budget[];
  onUpdateBudget: (categoryId: string, amount: number) => void;
  currencySymbol: string;
}

export function BudgetManager({
  categories,
  transactions,
  budgets,
  onUpdateBudget,
  currencySymbol
}: BudgetManagerProps) {
  const [activeType, setActiveType] = useState<'gasto' | 'ingreso'>('gasto');
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');

  // Determine current active period (Mayo 2026 based on mock/current date 2026-05-19)
  const currentYear = 2026;
  const currentMonthNum = 5; // Mayo

  // Filter transactions for current month
  const currentMonthTransactions = useMemo(() => {
    return transactions.filter(t => {
      if (!t.date) return false;
      const [y, m] = t.date.split('-').map(Number);
      return y === currentYear && m === currentMonthNum;
    });
  }, [transactions]);

  // Map categories of activeType to budgets and spent amounts
  const budgetList = useMemo(() => {
    const activeCats = categories.filter(c => c.type === activeType);
    
    return activeCats.map(cat => {
      // Find budget for this category
      const b = budgets.find(bg => bg.categoryId === cat.id);
      const budgetAmount = b ? b.amount : 0;
      
      // Calculate spent or earned this month
      const totalAmount = currentMonthTransactions
        .filter(t => t.category === cat.id)
        .reduce((sum, t) => sum + t.amount, 0);

      const pct = budgetAmount > 0 ? (totalAmount / budgetAmount) * 100 : 0;

      return {
        ...cat,
        budgetAmount,
        totalAmount,
        percentage: pct
      };
    });
  }, [categories, budgets, activeType, currentMonthTransactions]);

  const handleStartEdit = (categoryId: string, currentAmount: number) => {
    setEditingCategoryId(categoryId);
    setEditValue(currentAmount > 0 ? currentAmount.toString() : '');
  };

  const handleSaveEdit = (categoryId: string) => {
    const parsed = parseFloat(editValue);
    if (isNaN(parsed) || parsed < 0) {
      onUpdateBudget(categoryId, 0); // Clear or set to 0
    } else {
      onUpdateBudget(categoryId, parsed);
    }
    setEditingCategoryId(null);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-6">
      
      {/* Visual Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-base font-black text-slate-900 uppercase tracking-tight">🎯 Presupuestos Mensuales (Mayo 2026)</h3>
          <p className="text-xs text-slate-400 mt-1">
            Establece topes máximos de egresos o metas de ingresos anuales para automatizar alertas visuales de exceso.
          </p>
        </div>

        {/* Categories Tab selector */}
        <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
          <button
            onClick={() => setActiveType('gasto')}
            className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeType === 'gasto'
                ? 'bg-white text-rose-600 shadow-3xs font-black'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            💸 Límites de Gasto
          </button>
          <button
            onClick={() => setActiveType('ingreso')}
            className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeType === 'ingreso'
                ? 'bg-white text-emerald-600 shadow-3xs font-black'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            💰 Metas de Ingreso
          </button>
        </div>
      </div>

      {/* Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {budgetList.map((item) => {
          const isEditing = editingCategoryId === item.id;
          const isSaturated = item.percentage >= 100;
          const isApproaching = item.percentage >= 80 && item.percentage < 100;

          // Compute alert flags/visuals
          let statusColor = "bg-slate-100 text-slate-500";
          let barColor = "bg-indigo-600";
          let alertLabel = "";
          let iconOverride = null;

          if (activeType === 'gasto') {
            if (item.budgetAmount === 0) {
              statusColor = "bg-slate-100 text-slate-400 border border-slate-250/20";
              barColor = "bg-slate-200";
              alertLabel = "Sin presupuesto configurado";
            } else if (isSaturated) {
              statusColor = "bg-rose-50 text-rose-700 border border-rose-100";
              barColor = "bg-rose-500 animate-pulse";
              alertLabel = "🚨 ¡Límite superado!";
              iconOverride = <ShieldAlert className="w-3.5 h-3.5 text-rose-600 animate-bounce" />;
            } else if (isApproaching) {
              statusColor = "bg-amber-50 text-amber-700 border border-amber-150";
              barColor = "bg-amber-550";
              alertLabel = "⚠️ Cerca del límite (>80%)";
              iconOverride = <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />;
            } else {
              statusColor = "bg-emerald-50 text-emerald-750 border border-emerald-100";
              barColor = "bg-emerald-500";
              alertLabel = "Presupuesto bajo control";
              iconOverride = <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />;
            }
          } else {
            // Incomes Target
            if (item.budgetAmount === 0) {
              statusColor = "bg-slate-100 text-slate-400 border border-slate-250/20";
              barColor = "bg-slate-200";
              alertLabel = "Sin meta configurada";
            } else if (isSaturated) {
              statusColor = "bg-emerald-50 text-emerald-750 border border-emerald-100";
              barColor = "bg-emerald-500";
              alertLabel = "✨ ¡Meta alcanzada!";
              iconOverride = <Sparkles className="w-3.5 h-3.5 text-emerald-600" />;
            } else {
              statusColor = "bg-slate-105 text-slate-700 border border-slate-200";
              barColor = "bg-indigo-500";
              alertLabel = "Progreso hacia la meta";
              iconOverride = <Flame className="w-3.5 h-3.5 text-indigo-505" />;
            }
          }

          return (
            <div
              key={item.id}
              className={`p-4 bg-white border rounded-2xl shadow-3xs flex flex-col justify-between space-y-3.5 hover:shadow-2xs transition-all ${
                isEditing ? 'ring-1 ring-indigo-500/80 border-indigo-300' : 'border-slate-200/80'
              }`}
            >
              
              {/* Category Info header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-8.5 h-8.5 rounded-xl flex items-center justify-center text-white shrink-0"
                    style={{ backgroundColor: item.color }}
                  >
                    <CategoryIcon name={item.icon} size={15} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-black text-slate-900 truncate">{item.name}</p>
                    <span className={`inline-flex items-center gap-1 text-[9px] font-black uppercase mt-1 px-1.5 py-0.5 rounded-md ${statusColor}`}>
                      {iconOverride} {alertLabel}
                    </span>
                  </div>
                </div>

                {/* Inline Editing Switcher */}
                <div className="shrink-0">
                  {isEditing ? (
                    <div className="flex items-center gap-1 animate-fade-in">
                      <div className="relative">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">
                          {currencySymbol}
                        </span>
                        <input
                          type="number"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          placeholder="Monto"
                          autoFocus
                          className="w-20 pl-5 pr-1.5 py-1 text-xs font-black font-mono border border-indigo-400 bg-white rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-650"
                        />
                      </div>
                      <button
                        onClick={() => handleSaveEdit(item.id)}
                        className="p-1 px-1.5 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors cursor-pointer"
                        title="Guardar"
                      >
                        <Check size={11} strokeWidth={3} />
                      </button>
                      <button
                        onClick={() => setEditingCategoryId(null)}
                        className="p-1 px-1.5 bg-slate-100 text-slate-500 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
                        title="Cancelar"
                      >
                        <X size={11} strokeWidth={3} />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartEdit(item.id, item.budgetAmount)}
                      className="p-1.5 hover:bg-slate-50 border border-slate-200/80 text-slate-450 hover:text-slate-900 rounded-lg transition-all flex items-center gap-1 cursor-pointer text-[10px] font-bold"
                    >
                      <Pencil size={11} /> Configurar
                    </button>
                  )}
                </div>
              </div>

              {/* Numerical stats display */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50/50 p-2.5 rounded-xl border border-slate-100 text-xs text-slate-600">
                <div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 leading-none">Actual</span>
                  <p className="font-extrabold text-slate-900 font-mono mt-0.5">
                    {formatCurrency(item.totalAmount, currencySymbol)}
                  </p>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 leading-none">Presupuestado</span>
                  <p className="font-extrabold text-slate-900 font-mono mt-0.5">
                    {item.budgetAmount > 0 ? formatCurrency(item.budgetAmount, currencySymbol) : "—"}
                  </p>
                </div>
              </div>

              {/* Progress visual bar */}
              {item.budgetAmount > 0 && (
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="font-bold text-slate-450">Progreso mensual</span>
                    <span className={`font-black font-mono ${
                      activeType === 'gasto' 
                        ? (isSaturated ? 'text-rose-600' : isApproaching ? 'text-amber-600' : 'text-emerald-600')
                        : (isSaturated ? 'text-emerald-600' : 'text-slate-700')
                    }`}>
                      {item.percentage.toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${Math.min(item.percentage, 100)}%` }}
                      className={`h-full rounded-full transition-all duration-550 ${barColor}`}
                    />
                  </div>
                </div>
              )}
              
            </div>
          );
        })}
      </div>

    </div>
  );
}
