import React from 'react';
import {
  Utensils,
  Home,
  Car,
  Zap,
  Heart,
  Film,
  BookOpen,
  ShoppingBag,
  Plane,
  DollarSign,
  Briefcase,
  Code,
  TrendingUp,
  Gift,
  Building,
  PlusCircle,
  HelpCircle,
  LucideProps
} from 'lucide-react';

const iconMap: Record<string, React.FC<LucideProps>> = {
  Utensils,
  Home,
  Car,
  Zap,
  Heart,
  Film,
  BookOpen,
  ShoppingBag,
  Plane,
  DollarSign,
  Briefcase,
  Code,
  TrendingUp,
  Gift,
  Building,
  PlusCircle
};

interface CategoryIconProps {
  name: string;
  size?: number | string;
  className?: string;
  strokeWidth?: number | string;
}

export function CategoryIcon({ name, ...props }: CategoryIconProps) {
  const IconComponent = iconMap[name] || HelpCircle;
  return <IconComponent {...props} />;
}
