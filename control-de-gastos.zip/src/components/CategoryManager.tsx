import React, { useState } from 'react';
import { Category, TransactionType } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { Plus, Trash2, X, Sparkles, Check } from 'lucide-react';

interface CategoryManagerProps {
  categories: Category[];
  onAddCategory: (category: Omit<Category, 'id'>) => void;
  onDeleteCategory: (id: string) => void;
  onClose: () => void;
}

const PRESET_COLORS = [
  '#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16', '#22c55e', '#10b981', '#14b8a6',
  '#06b6d4', '#0ea5e9', '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899',
  '#f43f5e', '#64748b', '#475569', '#1e293b'
];

const PRESET_ICONS = [
  'Utensils', 'Home', 'Car', 'Zap', 'Heart', 'Film', 'BookOpen', 'ShoppingBag',
  'Plane', 'DollarSign', 'Briefcase', 'Code', 'TrendingUp', 'Gift', 'Building', 'PlusCircle'
];

export function CategoryManager({
  categories,
  onAddCategory,
  onDeleteCategory,
  onClose
}: CategoryManagerProps) {
  const [activeTab, setActiveTab] = useState<TransactionType>('gasto');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatColor, setNewCatColor] = useState(PRESET_COLORS[0]);
  const [newCatIcon, setNewCatIcon] = useState(PRESET_ICONS[0]);
  const [validationError, setValidationError] = useState('');

  const filteredCategories = categories.filter(c => c.type === activeTab);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    if (!newCatName.trim()) {
      setValidationError('Por favor ingresa un nombre para la categoría.');
      return;
    }

    // Comprobar duplicado para el mismo tipo
    const alreadyExists = categories.some(
      c => c.type === activeTab && c.name.toLowerCase() === newCatName.trim().toLowerCase()
    );
    if (alreadyExists) {
      setValidationError('Ya existe una categoría con ese nombre.');
      return;
    }

    onAddCategory({
      name: newCatName.trim(),
      type: activeTab,
      color: newCatColor,
      icon: newCatIcon
    });

    // Resetear form
    setNewCatName('');
    setShowAddForm(false);
  };

  // Se pueden eliminar solo las categorías que no sean las iniciales predeterminadas
  const isSystemCategory = (id: string) => {
    return id.startsWith('cat_') && !id.startsWith('cat_custom_');
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 max-w-lg w-full mx-auto font-sans">
      <div className="flex items-center justify-between mb-5 pb-3 border-b border-gray-100">
        <div>
          <h3 className="text-lg font-bold text-gray-950 flex items-center gap-2">
            🏷️ Administrar Categorías
          </h3>
          <p className="text-xs text-gray-500">Agrega o remueve tus categorías personalizadas</p>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 transition-colors p-1.5 rounded-full hover:bg-gray-100"
          type="button"
        >
          <X size={18} />
        </button>
      </div>

      {/* Tabs principal (Gastos vs Ingresos) */}
      <div className="grid grid-cols-2 gap-2 bg-gray-50 p-1 rounded-xl mb-4">
        <button
          onClick={() => {
            setActiveTab('gasto');
            setNewCatColor(PRESET_COLORS[0]); // default color
          }}
          className={`py-2 px-3 text-sm font-semibold rounded-lg transition-all text-center ${
            activeTab === 'gasto'
              ? 'bg-white shadow-xs text-red-650 font-bold'
              : 'text-gray-500 hover:text-gray-950'
          }`}
        >
          Gastos
        </button>
        <button
          onClick={() => {
            setActiveTab('ingreso');
            setNewCatColor(PRESET_COLORS[5]); // default color (greenish)
          }}
          className={`py-2 px-3 text-sm font-semibold rounded-lg transition-all text-center ${
            activeTab === 'ingreso'
              ? 'bg-white shadow-xs text-green-650 font-bold'
              : 'text-gray-500 hover:text-gray-950'
          }`}
        >
          Ingresos
        </button>
      </div>

      {!showAddForm ? (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest">
              Categorías de {activeTab === 'gasto' ? 'Gasto' : 'Ingreso'} ({filteredCategories.length})
            </span>
            <button
              onClick={() => {
                setShowAddForm(true);
                setValidationError('');
              }}
              className="flex items-center gap-1.5 py-1.5 px-3 bg-zinc-900 text-white rounded-lg text-xs font-semibold hover:bg-zinc-850 transition-all shadow-xs"
            >
              <Plus size={14} /> Nueva Categoría
            </button>
          </div>

          <div className="divide-y divide-gray-100 max-h-60 overflow-y-auto pr-1 border border-gray-100 rounded-xl bg-gray-50/50 p-2">
            {filteredCategories.length === 0 ? (
              <p className="text-center py-6 text-sm text-gray-400">Sin categorías registradas.</p>
            ) : (
              filteredCategories.map(cat => (
                <div key={cat.id} className="flex items-center justify-between py-2.5 px-2 bg-white rounded-lg mb-1.5 shadow-2xs border border-gray-100">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-semibold"
                      style={{ backgroundColor: cat.color }}
                    >
                      <CategoryIcon name={cat.icon} size={16} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-800">{cat.name}</p>
                      {isSystemCategory(cat.id) && (
                        <p className="text-[10px] text-gray-400">Sistema (Predefinida)</p>
                      )}
                    </div>
                  </div>

                  {!isSystemCategory(cat.id) ? (
                    <button
                      onClick={() => onDeleteCategory(cat.id)}
                      className="text-red-500 hover:text-red-700 p-1.5 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title="Eliminar categoría"
                    >
                      <Trash2 size={15} />
                    </button>
                  ) : (
                    <span className="text-[10px] bg-gray-150 text-gray-500 px-2 py-0.5 rounded-full font-medium">
                      Fija
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-gray-50 p-4 rounded-xl border border-gray-200/60 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-gray-200">
            <span className="text-xs font-bold text-gray-700 flex items-center gap-1">
              <Sparkles size={13} className="text-indigo-500" /> Crear nueva categoría
            </span>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={15} />
            </button>
          </div>

          {/* Nombre */}
          <div>
            <label className="block text-xs font-bold text-gray-500 mb-1">Nombre</label>
            <input
              type="text"
              placeholder="ej.: Mascotas, Gimnasio, Dividendos"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white rounded-lg border border-gray-200 text-gray-900 focus:outline-zinc-900"
              required
            />
          </div>

          {/* Paleta de Colores */}
          <div>
            <label className="block text-xs font-bold text-gray-500 mb-1.5">Color distintivo</label>
            <div className="grid grid-cols-8 gap-1.5 p-1 bg-white border border-gray-100 rounded-lg">
              {PRESET_COLORS.map(color => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setNewCatColor(color)}
                  className="w-6 h-6 rounded-full transition-transform hover:scale-110 shrink-0 flex items-center justify-center"
                  style={{ backgroundColor: color }}
                >
                  {newCatColor === color && (
                    <Check size={12} className="text-white drop-shadow-sm font-bold" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Muestrario de Iconos */}
          <div>
            <label className="block text-xs font-bold text-gray-500 mb-1.5">Símbolo / Icono</label>
            <div className="grid grid-cols-8 gap-2 p-1.5 bg-white border border-gray-100 rounded-lg max-h-24 overflow-y-auto">
              {PRESET_ICONS.map(iconName => (
                <button
                  key={iconName}
                  type="button"
                  onClick={() => setNewCatIcon(iconName)}
                  className={`w-7 h-7 rounded-md flex items-center justify-center border transition-all shrink-0 ${
                    newCatIcon === iconName
                      ? 'bg-zinc-900 border-zinc-900 text-white shadow-xs'
                      : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  <CategoryIcon name={iconName} size={15} />
                </button>
              ))}
            </div>
          </div>

          {validationError && (
            <p className="text-xs text-red-500 font-semibold">{validationError}</p>
          )}

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="flex-1 py-1.5 text-xs font-semibold bg-white border border-gray-200 hover:bg-gray-100 rounded-lg transition-colors text-gray-600"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-1.5 text-xs font-semibold bg-zinc-950 text-white hover:bg-zinc-850 rounded-lg transition-colors"
            >
              Crear Categoría
            </button>
          </div>
        </form>
      )}

      <div className="mt-5 text-[11px] text-gray-400 bg-gray-50 p-2.5 rounded-lg border border-gray-100">
        <span className="font-semibold">Nota:</span> Las categorías predefinidas de fábrica no pueden ser eliminadas para mantener la integridad de los informes pre-calculados, pero puedes complementarlas creando tus propias categorías infinitas de ingresos y de gastos.
      </div>
    </div>
  );
}
