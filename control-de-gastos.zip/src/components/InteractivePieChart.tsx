import { useState } from 'react';
import { CategoryIcon } from './CategoryIcon';
import { formatCurrency } from '../utils/financeUtils';

interface PieSegment {
  categoryId: string;
  categoryName: string;
  total: number;
  percentage: number;
  color: string;
  icon: string;
}

interface InteractivePieChartProps {
  data: PieSegment[];
  currencySymbol: string;
}

export function InteractivePieChart({ data, currencySymbol }: InteractivePieChartProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center py-12 text-xs text-slate-400 font-medium">
        No hay datos para construir el desglose visual.
      </div>
    );
  }

  // Pre-calculate cumulative percentages
  let cumulativePercent = 0;
  const segments = data.map((d, index) => {
    const startPercent = cumulativePercent;
    cumulativePercent += d.percentage / 100;
    return {
      ...d,
      startPercent,
      endPercent: cumulativePercent,
      index
    };
  });

  // Convert percentage coordinates to SVG point
  const getCoordinatesForPercent = (percent: number, radius: number) => {
    // Offset by -0.25 to start at 12 o'clock (top)
    const angle = (percent - 0.25) * 2 * Math.PI;
    const x = 100 + radius * Math.cos(angle);
    const y = 100 + radius * Math.sin(angle);
    return { x, y };
  };

  // Generate SVG path for an annular (donut) slice
  const getDonutPath = (
    startPercent: number,
    endPercent: number,
    innerRadius: number,
    outerRadius: number
  ) => {
    // If the slice is 100% or very close, return a circle representation instead to prevent arc collapse
    if (endPercent - startPercent >= 0.9999) {
      return `
        M 100 ${100 - outerRadius}
        A ${outerRadius} ${outerRadius} 0 1 1 99.99 ${100 - outerRadius}
        Z
        M 100 ${100 - innerRadius}
        A ${innerRadius} ${innerRadius} 0 1 0 99.99 ${100 - innerRadius}
        Z
      `;
    }

    const p1_outer = getCoordinatesForPercent(startPercent, outerRadius);
    const p2_outer = getCoordinatesForPercent(endPercent, outerRadius);
    const p1_inner = getCoordinatesForPercent(startPercent, innerRadius);
    const p2_inner = getCoordinatesForPercent(endPercent, innerRadius);

    const largeArcFlag = endPercent - startPercent > 0.5 ? 1 : 0;

    return `
      M ${p1_outer.x} ${p1_outer.y}
      A ${outerRadius} ${outerRadius} 0 ${largeArcFlag} 1 ${p2_outer.x} ${p2_outer.y}
      L ${p2_inner.x} ${p2_inner.y}
      A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${p1_inner.x} ${p1_inner.y}
      Z
    `.trim();
  };

  // Determine which sector is active (fallback to first or showing overall total)
  const activeSegment = hoveredIndex !== null ? segments[hoveredIndex] : null;
  const totalSum = data.reduce((sum, d) => sum + d.total, 0);

  return (
    <div className="flex flex-col md:flex-row items-center justify-around gap-8 p-4 bg-slate-50/45 rounded-2xl border border-slate-100">
      
      {/* SVG RING PORTION */}
      <div className="relative w-52 h-52 shrink-0 select-none">
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full drop-shadow-sm rotate-0 transition-transform duration-500"
        >
          {segments.map((seg) => {
            const isHovered = hoveredIndex === seg.index;
            const innerR = 64;
            const outerR = isHovered ? 86 : 80;

            const pathData = getDonutPath(seg.startPercent, seg.endPercent, innerR, outerR);

            return (
              <path
                key={seg.categoryId}
                d={pathData}
                fill={seg.color}
                className="transition-all duration-300 ease-out cursor-pointer hover:saturate-120 hover:opacity-95"
                onMouseEnter={() => setHoveredIndex(seg.index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
            );
          })}
        </svg>

        {/* Dynamic Inner Text inside Hollow Center */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none p-5">
          {activeSegment ? (
            <div className="animate-fade-in flex flex-col items-center">
              <span
                className="w-6 h-6 rounded-md flex items-center justify-center text-white mb-1 shadow-2xs"
                style={{ backgroundColor: activeSegment.color }}
              >
                <CategoryIcon name={activeSegment.icon} size={11} />
              </span>
              <p className="text-[10px] uppercase font-black tracking-wider text-slate-400 truncate max-w-[110px]">
                {activeSegment.categoryName}
              </p>
              <h5 className="text-sm font-black text-slate-900 font-mono mt-0.5">
                {formatCurrency(activeSegment.total, currencySymbol)}
              </h5>
              <p className="text-[9px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-full mt-1">
                {activeSegment.percentage.toFixed(1)}%
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <span className="text-xl mb-0.5">📊</span>
              <p className="text-[9px] uppercase font-black tracking-widest text-slate-400">Total Gastado</p>
              <h5 className="text-md font-black text-slate-900 font-mono mt-0.5">
                {formatCurrency(totalSum, currencySymbol)}
              </h5>
              <p className="text-[8px] text-slate-400 font-medium tracking-wide mt-1">Sectores Interactivos</p>
            </div>
          )}
        </div>
      </div>

      {/* RICH INTERACTIVE LEGEND GRID */}
      <div className="flex-1 w-full space-y-2 max-h-56 overflow-y-auto pr-1">
        {segments.map((seg) => {
          const isHovered = hoveredIndex === seg.index;
          return (
            <div
              key={seg.categoryId}
              onMouseEnter={() => setHoveredIndex(seg.index)}
              onMouseLeave={() => setHoveredIndex(null)}
              className={`flex items-center justify-between p-2 rounded-xl transition-all cursor-pointer border ${
                isHovered
                  ? 'bg-white border-slate-200 shadow-3xs scale-[1.01]'
                  : 'bg-transparent border-transparent hover:bg-slate-100/40'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span
                  className="w-3.5 h-3.5 rounded-full shrink-0 flex items-center justify-center text-white text-[8px]"
                  style={{ backgroundColor: seg.color }}
                >
                  <CategoryIcon name={seg.icon} size={8} />
                </span>
                <span className={`text-xs font-bold truncate ${isHovered ? 'text-indigo-900 font-black' : 'text-slate-700'}`}>
                  {seg.categoryName}
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-black text-slate-900 font-mono">
                  {formatCurrency(seg.total, currencySymbol)}
                </span>
                <span className="text-[9px] font-extrabold text-slate-400 bg-slate-100/90 py-0.5 px-1.5 rounded-md min-w-[36px] text-center">
                  {seg.percentage.toFixed(0)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
      
    </div>
  );
}
