import { useState } from 'react';
import { formatCurrency } from '../utils/financeUtils';

interface PeriodData {
  label: string;
  incomes: number;
  expenses: number;
}

interface InteractiveBarChartProps {
  data: PeriodData[];
  currencySymbol: string;
}

export function InteractiveBarChart({ data, currencySymbol }: InteractiveBarChartProps) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center py-12 text-xs text-slate-400 font-medium">
        No hay suficientes datos históricos para trazar la tendencia.
      </div>
    );
  }

  // Find max value for scaling
  const maxVal = Math.max(
    ...data.map((d) => Math.max(d.incomes, d.expenses)),
    100 // safety floor
  );

  // SVG dimensions
  const svgWidth = 500;
  const svgHeight = 220;
  const paddingLeft = 55;
  const paddingRight = 15;
  const paddingTop = 25;
  const paddingBottom = 35;

  const chartWidth = svgWidth - paddingLeft - paddingRight;
  const chartHeight = svgHeight - paddingTop - paddingBottom;

  // Grid lines helper (4 ticks)
  const yTicks = [0, 0.25, 0.5, 0.75, 1];

  // Hovered item card helper
  const hoveredItem = hoveredIdx !== null ? data[hoveredIdx] : null;

  return (
    <div className="bg-slate-50/45 border border-slate-100 p-5 rounded-2xl space-y-4">
      
      {/* Dynamic Header Tooltip */}
      <div className="h-14 flex items-center justify-between border-b border-slate-200/50 pb-2">
        {hoveredItem ? (
          <div className="flex items-center justify-between w-full animate-fade-in">
            <div>
              <p className="text-[10px] uppercase font-bold text-indigo-505 leading-none">
                Periodo: <span className="text-slate-800 font-black">{hoveredItem.label}</span>
              </p>
              <div className="flex gap-4 mt-1">
                <p className="text-xs font-semibold text-slate-550 flex items-center gap-1.5 leading-none">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                  Ingresos: <span className="font-bold text-slate-900 font-mono">{formatCurrency(hoveredItem.incomes, currencySymbol)}</span>
                </p>
                <p className="text-xs font-semibold text-slate-550 flex items-center gap-1.5 leading-none font-sans">
                  <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
                  Gastos: <span className="font-bold text-slate-900 font-mono">{formatCurrency(hoveredItem.expenses, currencySymbol)}</span>
                </p>
              </div>
            </div>
            
            <div className="text-right">
              <span className="text-[8px] uppercase font-black text-slate-400">Balance Neto</span>
              <p className={`text-xs font-black font-mono leading-none mt-0.5 ${
                hoveredItem.incomes - hoveredItem.expenses >= 0 ? 'text-emerald-600' : 'text-rose-600'
              }`}>
                {hoveredItem.incomes - hoveredItem.expenses >= 0 ? '+' : ''}
                {formatCurrency(hoveredItem.incomes - hoveredItem.expenses, currencySymbol)}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-slate-400 text-xs py-2">
            <span className="text-base">💡</span>
            <p className="font-medium">Posa el cursor sobre las columnas de barras para inspeccionar saldos detallados.</p>
          </div>
        )}
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full h-48 select-none">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          width="100%"
          height="100%"
          className="overflow-visible"
        >
          {/* Y-Axis Grid Lines & Labels */}
          {yTicks.map((tick) => {
            const y = paddingTop + chartHeight * (1 - tick);
            const valueLabel = formatCurrency(maxVal * tick, currencySymbol);

            return (
              <g key={`y-${tick}`} className="opacity-90">
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={svgWidth - paddingRight}
                  y2={y}
                  stroke="#E2E8F0"
                  strokeWidth={tick === 0 ? 1.5 : 1}
                  strokeDasharray={tick === 0 ? "" : "3,3"}
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 3.5}
                  textAnchor="end"
                  className="fill-slate-400 font-mono text-[8px] font-semibold"
                >
                  {valueLabel}
                </text>
              </g>
            );
          })}

          {/* Columns Drawing */}
          {data.map((item, index) => {
            const colWidth = chartWidth / data.length;
            const xOffset = paddingLeft + index * colWidth;

            // Compute heights (avoiding zero height making paths collapse)
            const incomeH = Math.max((item.incomes / maxVal) * chartHeight, 3);
            const expenseH = Math.max((item.expenses / maxVal) * chartHeight, 3);

            // Center positions
            const barWidth = Math.min(colWidth * 0.32, 16);
            const spacing = 2; // pixel space between grouped bars
            
            const incomeX = xOffset + colWidth / 2 - barWidth - spacing / 2;
            const expenseX = xOffset + colWidth / 2 + spacing / 2;

            const incomeY = paddingTop + chartHeight - incomeH;
            const expenseY = paddingTop + chartHeight - expenseH;

            const isHovered = hoveredIdx === index;

            return (
              <g
                key={`col-${index}`}
                onMouseEnter={() => setHoveredIdx(index)}
                onMouseLeave={() => setHoveredIdx(null)}
                className="cursor-pointer"
              >
                {/* Visual Highlight Column Background */}
                <rect
                  x={xOffset + 2}
                  y={paddingTop - 5}
                  width={colWidth - 4}
                  height={chartHeight + 10}
                  fill={isHovered ? "rgba(79, 70, 229, 0.04)" : "transparent"}
                  rx={8}
                  className="transition-all duration-200"
                />

                {/* Income Bar (Emerald) */}
                <rect
                  x={incomeX}
                  y={incomeY}
                  width={barWidth}
                  height={incomeH}
                  fill={isHovered ? "#059669" : "#10b981"}
                  rx={3}
                  className="transition-all duration-300 transform origin-bottom hover:brightness-110"
                />

                {/* Expense Bar (Rose) */}
                <rect
                  x={expenseX}
                  y={expenseY}
                  width={barWidth}
                  height={expenseH}
                  fill={isHovered ? "#e11d48" : "#f43f5e"}
                  rx={3}
                  className="transition-all duration-300 transform origin-bottom hover:brightness-110"
                />

                {/* X-Axis Label */}
                <text
                  x={xOffset + colWidth / 2}
                  y={paddingTop + chartHeight + 16}
                  textAnchor="middle"
                  className={`text-[9px] font-bold select-none transition-colors ${
                    isHovered ? "fill-indigo-650 font-black" : "fill-slate-450"
                  }`}
                >
                  {item.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

    </div>
  );
}
