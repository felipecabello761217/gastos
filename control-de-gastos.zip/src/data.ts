import { Category, Transaction, Budget } from './types';

export const DEFAULT_CATEGORIES: Category[] = [
  // Gastos
  { id: 'cat_alimentacion', name: 'Alimentación', type: 'gasto', color: '#f59e0b', icon: 'Utensils' }, // Amber
  { id: 'cat_vivienda', name: 'Vivienda', type: 'gasto', color: '#ef4444', icon: 'Home' }, // Red
  { id: 'cat_transporte', name: 'Transporte', type: 'gasto', color: '#3b82f6', icon: 'Car' }, // Blue
  { id: 'cat_servicios', name: 'Servicios', type: 'gasto', color: '#06b6d4', icon: 'Zap' }, // Cyan
  { id: 'cat_salud', name: 'Salud', type: 'gasto', color: '#10b981', icon: 'Heart' }, // Emerald
  { id: 'cat_ocio', name: 'Ocio y Entretenimiento', type: 'gasto', color: '#ec4899', icon: 'Film' }, // Pink
  { id: 'cat_educacion', name: 'Educación', type: 'gasto', color: '#8b5cf6', icon: 'BookOpen' }, // Violet
  { id: 'cat_compras', name: 'Ropa y Compras', type: 'gasto', color: '#a855f7', icon: 'ShoppingBag' }, // Purple
  { id: 'cat_viajes', name: 'Viajes', type: 'gasto', color: '#14b8a6', icon: 'Plane' }, // Teal
  { id: 'cat_otros_gastos', name: 'Otros Gastos', type: 'gasto', color: '#6b7280', icon: 'DollarSign' }, // Gray

  // Ingresos
  { id: 'cat_salario', name: 'Salario / Sueldo', type: 'ingreso', color: '#22c55e', icon: 'Briefcase' }, // Green
  { id: 'cat_freelance', name: 'Freelance / Proyectos', type: 'ingreso', color: '#10b981', icon: 'Code' }, // Emerald
  { id: 'cat_inversiones', name: 'Inversiones', type: 'ingreso', color: '#3b82f6', icon: 'TrendingUp' }, // Blue
  { id: 'cat_regalos', name: 'Regalos / Premios', type: 'ingreso', color: '#eab308', icon: 'Gift' }, // Yellow
  { id: 'cat_alquileres', name: 'Rentasantas', type: 'ingreso', color: '#ec4899', icon: 'Building' }, // Pink
  { id: 'cat_otros_ingresos', name: 'Otros Ingresos', type: 'ingreso', color: '#6366f1', icon: 'PlusCircle' } // Indigo
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  // Mayo 2026 (Actual)
  {
    id: 't-may-1',
    type: 'ingreso',
    amount: 3200,
    category: 'cat_salario',
    date: '2026-05-01',
    description: 'Nómina mensual Mayo',
    notes: 'Transferencia bancaria recibida a primera hora'
  },
  {
    id: 't-may-2',
    type: 'gasto',
    amount: 850,
    category: 'cat_vivienda',
    date: '2026-05-02',
    description: 'Alquiler departamento',
    notes: 'Pago mensual del piso'
  },
  {
    id: 't-may-3',
    type: 'gasto',
    amount: 145.50,
    category: 'cat_alimentacion',
    date: '2026-05-03',
    description: 'Compra semanal supermercado',
    notes: 'Fruta, verdura, carne y despensa semanal'
  },
  {
    id: 't-may-4',
    type: 'ingreso',
    amount: 750,
    category: 'cat_freelance',
    date: '2026-05-05',
    description: 'Diseño Landing Page Cliente',
    notes: 'Proyecto Figma y desarrollo de frontend'
  },
  {
    id: 't-may-5',
    type: 'gasto',
    amount: 45.00,
    category: 'cat_transporte',
    date: '2026-05-06',
    description: 'Gasolina auto',
    notes: 'Tanque lleno'
  },
  {
    id: 't-may-6',
    type: 'gasto',
    amount: 110.00,
    category: 'cat_servicios',
    date: '2026-05-08',
    description: 'Internet y Electricidad',
    notes: 'Factura bimestral de luz e internet mensual'
  },
  {
    id: 't-may-7',
    type: 'gasto',
    amount: 68.00,
    category: 'cat_alimentacion',
    date: '2026-05-10',
    description: 'Cena restaurante italiano',
    notes: 'Celebración de fin de semana'
  },
  {
    id: 't-may-8',
    type: 'gasto',
    amount: 14.99,
    category: 'cat_ocio',
    date: '2026-05-12',
    description: 'Suscripción Streaming',
    notes: 'Cobro automático mensual'
  },
  {
    id: 't-may-9',
    type: 'gasto',
    amount: 35.00,
    category: 'cat_educacion',
    date: '2026-05-14',
    description: 'Libros de TypeScript',
    notes: 'Manual de buenas prácticas avanzado'
  },
  {
    id: 't-may-10',
    type: 'gasto',
    amount: 80.00,
    category: 'cat_salud',
    date: '2026-05-15',
    description: 'Consulta Oftalmológica',
    notes: 'Revisión anual y receta para lentes'
  },
  {
    id: 't-may-11',
    type: 'gasto',
    amount: 120.30,
    category: 'cat_alimentacion',
    date: '2026-05-17',
    description: 'Compra supermercado quincenal',
    notes: 'Repostura de alimentos no perecederos'
  },
  {
    id: 't-may-12',
    type: 'gasto',
    amount: 50.00,
    category: 'cat_otros_gastos',
    date: '2026-05-18',
    description: 'Regalo cumpleaños madre',
    notes: 'Flores y bombones'
  },
  {
    id: 't-may-13',
    type: 'ingreso',
    amount: 300.00,
    category: 'cat_freelance',
    date: '2026-05-19',
    description: 'Consultoría técnica express',
    notes: 'Resolución de bug en ambiente productivo'
  },

  // Abril 2026 (Mes anterior para informes comparativos)
  {
    id: 't-apr-1',
    type: 'ingreso',
    amount: 3200,
    category: 'cat_salario',
    date: '2026-04-01',
    description: 'Nómina mensual Abril'
  },
  {
    id: 't-apr-2',
    type: 'gasto',
    amount: 850,
    category: 'cat_vivienda',
    date: '2026-04-02',
    description: 'Alquiler departamento'
  },
  {
    id: 't-apr-3',
    type: 'gasto',
    amount: 130.00,
    category: 'cat_alimentacion',
    date: '2026-04-04',
    description: 'Compra supermercado'
  },
  {
    id: 't-apr-4',
    type: 'gasto',
    amount: 50.00,
    category: 'cat_transporte',
    date: '2026-04-06',
    description: 'Combustible'
  },
  {
    id: 't-apr-5',
    type: 'gasto',
    amount: 14.99,
    category: 'cat_ocio',
    date: '2026-04-12',
    description: 'Suscripción Streaming'
  },
  {
    id: 't-apr-6',
    type: 'gasto',
    amount: 120.00,
    category: 'cat_compras',
    date: '2026-04-15',
    description: 'Zapatillas deportivas'
  },
  {
    id: 't-apr-7',
    type: 'gasto',
    amount: 75.00,
    category: 'cat_ocio',
    date: '2026-04-20',
    description: 'Salida fin de semana con amigos'
  },
  {
    id: 't-apr-8',
    type: 'ingreso',
    amount: 450,
    category: 'cat_regalos',
    date: '2026-04-23',
    description: 'Regalo cumpleaños'
  }
];

export const STORAGE_KEYS = {
  TRANSACTIONS: 'finanzas_transacciones',
  CATEGORIES: 'finanzas_categorias',
  BUDGETS: 'finanzas_presupuestos'
};

export const DEFAULT_BUDGETS: Budget[] = [
  { categoryId: 'cat_alimentacion', amount: 350 },
  { categoryId: 'cat_vivienda', amount: 900 },
  { categoryId: 'cat_transporte', amount: 100 },
  { categoryId: 'cat_servicios', amount: 150 },
  { categoryId: 'cat_ocio', amount: 200 },
  { categoryId: 'cat_compras', amount: 150 },
  { categoryId: 'cat_salario', amount: 3000 } // Income target budget example
];

export function loadTransactions(): Transaction[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error al cargar transacciones del localStorage:', error);
  }
  // Si no hay datos, inicializar con las transacciones predeterminadas
  saveTransactions(INITIAL_TRANSACTIONS);
  return INITIAL_TRANSACTIONS;
}

export function saveTransactions(transactions: Transaction[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  } catch (error) {
    console.error('Error al guardar transacciones en el localStorage:', error);
  }
}

export function loadCategories(): Category[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error al cargar categorías del localStorage:', error);
  }
  saveCategories(DEFAULT_CATEGORIES);
  return DEFAULT_CATEGORIES;
}

export function saveCategories(categories: Category[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  } catch (error) {
    console.error('Error al guardar categorías en el localStorage:', error);
  }
}

export function loadBudgets(): Budget[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BUDGETS);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error al cargar presupuestos del localStorage:', error);
  }
  saveBudgets(DEFAULT_BUDGETS);
  return DEFAULT_BUDGETS;
}

export function saveBudgets(budgets: Budget[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
  } catch (error) {
    console.error('Error al guardar presupuestos en el localStorage:', error);
  }
}

