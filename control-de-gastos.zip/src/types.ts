export type TransactionType = 'ingreso' | 'gasto';

export interface Category {
  id: string;
  name: string;
  type: TransactionType;
  color: string; // Tailwind class color or hex code
  icon: string;  // Lucide icon name
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string; // category ID
  date: string;     // YYYY-MM-DD
  description: string;
  notes?: string;
}

export interface MonthlySummary {
  year: number;
  month: number; // 0-based
  totalIncomes: number;
  totalExpenses: number;
  balance: number;
}

export interface Budget {
  categoryId: string;
  amount: number;
}


export interface WeeklySummary {
  startOfWeek: string; // YYYY-MM-DD
  endOfWeek: string;   // YYYY-MM-DD
  totalIncomes: number;
  totalExpenses: number;
  balance: number;
}
